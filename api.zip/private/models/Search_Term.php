<?php

class Search_Term extends Util{

    public $id;
    public $term;
    public $created;
    public $admin_id;
    public $count;

}