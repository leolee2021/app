<?php


class Push_Notification extends Util{

    public $id;
    public $title;
    public $message;
    public $admin_id;
    
}