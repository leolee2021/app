<?php

class Smtp_Config extends Util{
    public $id;
    public $host;
    public $sender_email;
    public $username;
    public $smtp_password;
    public $port;
    public $encryption;
    public $admin_id;
}