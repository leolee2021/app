<?php

class Admob extends Util{

    public $id;
    public $banner_status;
    public $banner_id;
    public $banner_unit_id;
    public $interstitial_status;
    public $interstitial_id;
    public $interstitial_unit_id;
    public $video_status;
    public $video_id;
    public $video_unit_id;
    public $admin_id;

}