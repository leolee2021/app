<?php

class Favourite extends Util{
    public $id;
    public $user_id;
    public $track_id;
    public $created;

}