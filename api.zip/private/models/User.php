<?php

class User extends Util{

    public $id;
    public $type;
    public $admin_id;
    public $username;
    public $gender;
    public $social_id;
    public $email;
    public $password;
    public $image_name;
    public $resolution;
    public $created;

}