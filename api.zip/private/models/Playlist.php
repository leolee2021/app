<?php

class Playlist extends Util{

    public $id;
    public $title;
    public $user_id;
    public $admin_id;
    public $created;
    public $saving_count;
    public $image_name;
    public $resolution;
    public $status;
    public $featured;
    public $image_uploaded_by_admin;

}