<div class="tp-layer"></div>

<div class="header">
    <a href="#" id="toggle-sidebar" class="toggle-sidebar"><i class="ion-android-menu"></i></a>

    <a href="#" id="toggle-setting" class="toggle-sidebar toggle-setting"><i class="ion-android-more-vertical"></i></a>

    <a class="toolbar-left" href="#">
        <h4 class="site-title"><b><?php echo $s_config->title; ?></b></h4>
    </a><!--toolbar-left-->

    <div class="toolbar-right" id="setting-dropdown">
        <a href="profile.php">Profile</a>
        <a href="logout.php">Logout</a>
    </div><!--toolbar-right-->
</div><!--header-->

