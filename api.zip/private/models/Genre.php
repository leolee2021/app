<?php

class Genre extends Util{

    public $id;
    public $title;
    public $admin_id;
    public $created;

}