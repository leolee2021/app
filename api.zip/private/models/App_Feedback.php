<?php

class App_Feedback extends Util{

    public $id;
    public $email;
    public $feedback;
    public $created;
    public $admin_id;

}