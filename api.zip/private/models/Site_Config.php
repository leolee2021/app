<?php

class Site_Config extends Util{

    public $id;
    public $image_name;
    public $resolution;
    public $title;
    public $tag_line;
    public $firebase_auth;
    public $admin_id;
    public $push_title;
    public $push_message;
    
}