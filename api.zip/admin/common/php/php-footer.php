
<!-- jQuery library -->
<script src="plugin-frameworks/jquery-3.4.1.min.js"></script>

<script src="plugin-frameworks/trumbowyg.min.js"></script>

<!-- MASONRY library -->
<script src="plugin-frameworks/masonry.pkgd.min.js"></script>

<script src="plugin-frameworks/jquery.magnific-popup.min.js"></script>

<script src="plugin-frameworks/id3-minimized.js"></script>
<script src="plugin-frameworks/cropper.min.js"></script>
<script src="plugin-frameworks/jquery-cropper.min.js"></script>

<!-- Main Script -->

<script src="common/other/script.js"></script>

</body>
</html>