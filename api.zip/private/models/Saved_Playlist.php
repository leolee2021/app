<?php

class Saved_Playlist extends Util{

    public $id;
    public $user_id;
    public $playlist_id;
    public $created;

}