<?php

$site_config = Session::get_session(new Site_Config());

if(empty($site_config)){
	$setting = new Setting();
	$setting = $setting->where(["admin_token" => ADMIN_TOKEN])->one();

	$site_config = new Site_Config();
	$site_config = $site_config->where(["admin_id" => $setting->admin_id])->one();
}

$site_header["title"] = DEFAULT_PAGE_TITLE;
$site_header["meta_description"] = DEFAULT_META_DESCRIPTION;
$site_header["meta_keywords"] = DEFAULT_META_KEYWORDS;
$site_header["image"] = DEFAULT_HEADING_IMAGE;

if(!empty($site_config->image_name)) $site_header["image"] = ADMIN_THUMB_LINK . $site_config->image_name;

$current = basename($_SERVER["SCRIPT_FILENAME"]);

if(isset($_GET["id"])){
    if($current == "track.php") $site_header = Helper::generate_track_header($_GET["id"], $site_header);
    else if($current == "artist.php") $site_header = Helper::generate_artist_header($_GET["id"], $site_header);
    else if($current == "album.php") $site_header = Helper::generate_album_header($_GET["id"], $site_header);
    else if($current == "genre.php") $site_header = Helper::generate_genre_header($_GET["id"], $site_header);
    else if($current == "tag.php") $site_header = Helper::generate_tag_header($_GET["id"], $site_header);
}


if(empty(Session::get_session(new User_Token()))){
	$user_token = new User_Token();
	$user_token->ip_address = Helper::get_client_ip();
	$user_token->user_token = Helper::unique_code(25);
	$user_token->created = date(DATE_FORMAT);

	$user_token_form_db = new User_Token();
	$user_token_form_db = $user_token_form_db->where(["ip_address" => $user_token->ip_address])->one();

	$success = false;
	if(!empty($user_token_form_db)){
		if($user_token->where(["id" => $user_token_form_db->id])->update()) $success = true;
	}else{
		if($user_token->save()) $success = true;
	}

	$session_user_token = new User_Token();
	$session_user_token->user_token = $user_token->user_token;

	if($success) Session::set_session($session_user_token);
    
}else{

    $user_token = Session::get_session(new User_Token());
    $user_token_form_db = new User_Token();
    $user_token_form_db = $user_token_form_db->where(["user_token" => $user_token->user_token])->one();

    if(empty($user_token_form_db)){

        $user_token = new User_Token();
        $user_token->ip_address = Helper::get_client_ip();
        $user_token->user_token = Helper::unique_code(25);
        $user_token->created = date(DATE_FORMAT);

        $user_token_form_db = new User_Token();
        $user_token_form_db = $user_token_form_db->where(["ip_address" => $user_token->ip_address])->one();

        $success = false;
        if(!empty($user_token_form_db)){
            if($user_token->where(["id" => $user_token_form_db->id])->update()) $success = true;
        }else{
            if($user_token->save()) $success = true;
        }

        $session_user_token = new User_Token();
        $session_user_token->user_token = $user_token->user_token;

        if($success) Session::set_session($session_user_token);
    }
}

$facebook_login_url = '';
$login_button = '';

if(!$logged_in){
    $gClient = new Google_Client();
    $gClient->setClientId(GOOGLE_LOGIN_CLIENT_ID);
    $gClient->setClientSecret(GOOGLE_LOGIN_CLIENT_SECRET);
    $gClient->setRedirectUri(GOOGLE_LOGIN_REDIRECT_URL);

    $gClient->addScope('email');
    $gClient->addScope('profile');

	$facebook = new \Facebook\Facebook([
		'app_id'				=> FACEBOOK_LOGIN_APP_ID,
		'app_secret'			=> FACEBOOK_LOGIN_APP_SECRET,
        'default_graph_version' => 'v3.2',
	]);


	$facebook_helper = $facebook->getRedirectLoginHelper();

    if(isset($_GET["code"])) {
        $google_token = $gClient->fetchAccessTokenWithAuthCode($_GET["code"]);

		if(!empty($google_token) && !isset($google_token['error'])){

            $gClient->setAccessToken($google_token['access_token']);
            $google_service = new Google_Service_Oauth2($gClient);
            $data = $google_service->userinfo->get();
            /*$_SESSION['google_token'] = $gClient->getAccessToken();*/

            Helper::social_login($data, USER_TYPE_GMAIL);

		}else{
            $facebook_token = $facebook_helper->getAccessToken();

            if(!empty($facebook_token)){
                $facebook->setDefaultAccessToken($facebook_token);

                $graph_response = $facebook->get("/me?fields=id,name,email", $facebook_token);
                $facebook_user_info = $graph_response->getGraphUser();
                /*$_SESSION['facebook_token'] = $gClient->getAccessToken();*/

                Helper::social_login($facebook_user_info, USER_TYPE_FACEBOOK);
            }
		}
    }

    if(!isset($_SESSION['google_token'])) {
        $login_button = '<a class="btn-login login-with-google-btn" href="' . $gClient->createAuthUrl().'">Login With Google</a>';
    }

	if(!isset($_SESSION['facebook_token'])) {

		$facebook_login_url = $facebook_helper->getLoginUrl(FACEBOOK_LOGIN_REDIRECT_URL);

		// Render Facebook login button
		$facebook_login_url = '<a class="btn-login login-with-facebook-btn" href="' . $facebook_login_url . '">Login With Facebook</a>';

	}
}


?>

<!DOCTYPE HTML>
<html lang="en">
<head>

	<?php echo Helper::page_meta($site_header); ?>

	<!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700%7CLato:400,700%7CRoboto:400,500" rel="stylesheet">

	<!-- Font Icons -->
	<link rel="stylesheet" href="fonts/ionicons.css">

	<!-- Styles -->
	<link rel="stylesheet" href="plugin-frameworks/swiper.min.css">
	<link rel="stylesheet" href="plugin-frameworks/bootstrap-grid.min.css">
	<link rel="stylesheet" href="common/other/styles.css">
</head>

<body>


<div class="track-download-popup" id="track-download-popup">
	<div class="popup-inner">

		<a class="close-btn" href="#" data-close="#track-download-popup"><i class="ion-android-close"></i></a>

		<h5 class="popup-header">

		</h5><!--popup-header-->

		<div class="popup-body">

		</div><!--popup-body-->

	</div><!--popup-inner-->
</div><!--user-audio-player-->



<div class="track-detail-popup" id="track-detail-popup">

    <div class="popup-inner">

		<a class="close-btn" href="#" data-close="#track-detail-popup"><i class="ion-android-close"></i></a>

        <h5 class="popup-header">
			Download
        </h5><!--popup-header-->

        <div class="popup-body">

        </div><!--popup-body-->
        
    </div><!--popup-inner-->
</div><!--user-audio-player-->



<div class="active page-loader btn-loader loader-big"><div class="active ajax-loader"></div></div>

<div class="user-audio-player" id="fixed-bottom-player">
	<a id="player-close-btn" href="#"><i class="ion-close-round"></i></a>
	<div class="fixed-player-inner" >
		<a class="player-detail" href="#">
			<span class="arrow-top-btn" href="#"><i class="ion-android-arrow-dropup"></i></span>
			<img src="" alt="">
			<p class="title"></p>
			<p class="artist"></p>
		</a>
		<div class="player-wrapper">
			<audio controls="" class="track track_name" preload="auto">
				<source src="" type="audio/mpeg">
			</audio>
		</div>
	</div><!--fixed-player-inner-->

	<div id="google-adsence">
        <a href="#"><img src="https://place-hold.it/300x70" alt=""></a>
	</div>

</div><!--user-audio-player-->



<div class="login-register" id="login-register">
	<div class="inner">

		<div class="register-tab tab active" id="register-tab">
			<a class="close-btn" href="#" data-close="#login-register"><i class="ion-android-close"></i></a>
			<h4 class="mb-20">Register</h4>

			<div class="loader-black btn-loader loader-big"><span class="active ajax-loader"><span></span></span></div>
			<h5 class="mt-10 mb-15 ajax-message"></h5>

			<form data-url="<?php echo MAIN_API; ?>" method="post">

				<input type="hidden" name="action" value="<?php echo REGISTER_ACTION; ?>"/>
				<input data-ajax-field="true" type="text" name="username" placeholder="Username"/>
				<input data-ajax-field="email" type="text" name="email" placeholder="Email"/>

				<div class="mt-20" data-ajax-field="radio">
					<label class="radio-container mr-15">Male
						<input type="radio" name="gender" value="<?php echo GENDER_TYPE_MALE; ?>">
						<span class="checkmark"></span>
					</label>

					<label class="radio-container">Female
						<input type="radio" name="gender" value="<?php echo GENDER_TYPE_FEMALE; ?>">
						<span class="checkmark"></span>
					</label>
				</div>

				<button type="submit" >Submit</button>
			</form>

			<h6 class="center-text mt-25"><a href="#" data-tab="#login-tab" class="link">Already have an account?</a></h6>
		</div><!--register-tab-->

		<div class="login-tab tab" id="login-tab">
			<a class="close-btn" href="#" data-close="#login-register"><i class="ion-android-close"></i></a>
			<h4 class="mb-20">Login</h4>
			<h5 class="mt-10 mb-10 ajax-message"></h5>
			<div class="loader-black btn-loader loader-big"><span class="active ajax-loader"><span></span></span></div>

			<form data-url="<?php echo MAIN_API; ?>"  method="post">
				<input type="hidden" name="action" value="<?php echo LOGIN_ACTION; ?>"/>
				<input data-ajax-field="email" type="text" name="email" placeholder="Email"/>
				<input data-ajax-field="true" type="password" name="password" placeholder="Password"/>

                <h6 class="mt-20 right-text">
                    <a class="link" href="#" data-tab="#forgot-password-tab" id="forgot-password-btn">Forgot Password?</a></h6>

				<button type="submit" >Submit</button>
			</form>

            <?php echo $login_button; ?>

            <?php echo $facebook_login_url; ?>

			<h6 class="center-text mt-25"><a data-tab="#register-tab" href="#" class="link">New Here?</a></h6>
		</div><!--register-tab-->

        <div class="forgot-password-tab tab" id="forgot-password-tab">
            <a class="close-btn" href="#" data-close="#login-register"><i class="ion-android-close"></i></a>
            <h4 class="mb-20">Forgot Password</h4>
            <h5 class="mt-10 mb-10 ajax-message"></h5>
            <div class="loader-black btn-loader loader-big"><span class="active ajax-loader"><span></span></span></div>

            <form data-url="<?php echo MAIN_API; ?>"  method="post">
                <input type="hidden" name="action" value="<?php echo FORGOT_PASSWORD_ACTION; ?>"/>
                <input data-ajax-field="email" type="text" name="email" placeholder="Email"/>

                <button type="submit" >Submit</button>
            </form>

            <h6 class="center-text mt-25"><a href="#" data-tab="#login-tab" class="link">Login here</a></h6>
        </div><!--register-tab-->

	</div><!--login-register-->
</div><!--login-register-->


<header>
	<div class="container h-100">
		<div class="pos-relative h-100">

			<a class="logo not-load" data-page="home" data-title="Home" href="index.php"><img src="images/logo_black.png" alt=""></a>
			<div class="right-area">
				<ul class="main-menu" id="main-menu">
					<li><a class="not-load" data-page="home" data-title="Home" href="index.php">Home</a></li>
                    <li><a class="not-load" data-page="tracks" data-title="Tracks" href="track.php">Songs</a></li>
					<li><a class="not-load" data-page="my-music" data-title="My Music" href="my-music.php">My Music</a></li>

                    <?php if($logged_in){ ?>
                        <li class="dropdown-item">
                            <a href="#">
                                <?php echo $user->username; ?>
                                <i class="ion-android-arrow-dropdown"></i>
                            </a>
                            <ul class="dropdown-list">
                                <li>
                                    <a class="not-load" data-page="profile" data-title="Profile" href="profile.php">Profile</a>
                                    <a data-confirm="Are you sure?" href="logout.php">Logout</a>
                                </li>
                            </ul>
                        </li>
                    <?php } else { ?>
                        <li><a href="#" id="login-btn">Login</a></li>
                    <?php } ?>
				</ul>

				<a class="toggle-menu-btn" id="hamburger-menu" href="#"><i class="ion-android-menu"></i></a>

				<a class="search-btn" id="search-btn" href="#search-area"><i class="ion-android-search"></i></a>
			</div><!--right-area-->
		</div><!-- pos-relative -->
	</div><!-- container -->
</header>

<div class="search-area" id="search-area">
	<div class="search-inner">

		<a class="close-btn" href="#" data-close="#search-area"><i class="ion-android-close"></i></a>
		<div class="search-wrapper">

			<form class="input-wrapper">
				<input name="search" type="text" placeholder="Search Here">
				<button type="submit"><i class="ion-android-search"></i></button>
			</form>

			<div class="link-item" id="popular_search"></div>

			<div class="link-item" id="recent_search"></div>

		</div><!--search-wrapper-->
	</div><!--search-area-->
</div><!--search-area-->


<div class="popup-toast">
	<i class="ion-ios-bell"></i>
	<div class="toast-right">
        <h5 class="title"></h5>
        <h6 class="desc"></h6>

    </div>
</div>
