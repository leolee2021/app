<?php

class Playlist_Track extends Util{

    public $id;
    public $playlist_id;
    public $track_id;
    public $created;

}