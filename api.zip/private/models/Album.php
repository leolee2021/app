<?php

class Album extends Util{

    public $id;
    public $title;
    public $image_name;
    public $resolution;
    public $description;
    public $created;
    public $admin_id;
    public $status;
    public $artists;
    public $genres;
    public $tags;
    public $featured;

}