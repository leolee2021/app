<?php

class Artist extends Util{

    public $id;
    public $name;
    public $genres;
    public $image_name;
    public $resolution;
    public $description;
    public $created;
    public $admin_id;
    public $status;
    public $listening_count;

}