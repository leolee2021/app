<?php

class Admin extends Util{

    public $id;

    public $first_name;
    public $last_name;
    public $location;
    public $phone;
    public $speaks;
    public $description;

    public $username;
    public $email;
    public $password;

    public $image_name;
    public $resolution;
    
}