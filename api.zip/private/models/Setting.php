<?php

class Setting extends Util{

    public $id;
    public $admin_token;
    public $currency_font;
    public $currency;
    public $tax;
    public $admin_id;

}