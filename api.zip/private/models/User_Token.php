<?php

class User_Token extends Util{
    public $id;
    public $ip_address;
    public $user_token;
    public $created;
}